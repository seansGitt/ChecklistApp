//
//  Checklist.swift
//  Checklists
//
//  Created by Chetan Lamba on 2016-10-28.
//  Copyright © 2016 Chetan Lamba. All rights reserved.
//

import UIKit

class Checklist: NSObject {
    
    var name = ""
    
    init(name: String) {
        
        self.name = name
        super.init()
    }

}
